﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoo
{
    public class Animal
    {
        string name;
        public Animal(string name)
        {
            this.name = name;
        }
    }
}
