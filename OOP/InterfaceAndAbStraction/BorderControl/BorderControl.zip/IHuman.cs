﻿namespace BorderControl.Models.Interfaces;

public interface IHuman
{
    string Name { get; set; }
    int Age { get; set;}

}
