﻿namespace BorderControl.Models.Interfaces;

public interface IRobot
{
    string Model { get; set; }
}