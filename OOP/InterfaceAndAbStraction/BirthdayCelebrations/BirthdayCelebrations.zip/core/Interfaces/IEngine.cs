﻿
namespace BirthdayCelebrations.core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
