﻿
namespace BirthdayCelebrations.Models.Interfaces
{
    public interface IBirthdatable
    {
        string Birthdate { get; set; }
    }
}
