﻿namespace BirthdayCelebrations.Models.Interfaces;

public interface ICitizen
{
    string Name { get; set; }
    int Age { get; set;}

}
