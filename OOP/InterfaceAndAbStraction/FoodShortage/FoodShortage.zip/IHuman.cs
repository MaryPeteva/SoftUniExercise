﻿namespace FoodShortage.Models.Interfaces;
public interface IHuman 
{
    public string Name { get; set; }
}