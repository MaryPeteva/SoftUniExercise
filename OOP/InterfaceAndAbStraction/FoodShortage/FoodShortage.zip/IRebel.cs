﻿namespace FoodShortage.Models.Interfaces;

public interface IRebel 
{
    string Group { get; set; }
}