﻿

namespace WildFarm.Factories.Interfaces
{
    public interface IFarm
    {
        IFarm Create();
    }
}
